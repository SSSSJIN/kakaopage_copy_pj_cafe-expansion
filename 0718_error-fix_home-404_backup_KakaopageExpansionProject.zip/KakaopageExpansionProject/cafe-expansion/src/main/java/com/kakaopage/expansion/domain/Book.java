package com.kakaopage.expansion.domain;

public class Book {
    private Long id;
    private String title;
    // getter/setter
    // ...
}
