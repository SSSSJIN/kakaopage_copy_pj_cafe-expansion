import numpy as np
import itertools

from module_aladin.config import *

import os,sys

## FUNCTIONS -METRICS/ENCODING
